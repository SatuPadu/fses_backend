<?php

namespace Tests\Unit;

use Tests\TestCase;
use Mockery;
use App\Modules\Articles\Services\UserPreferencesService;
use App\Modules\Articles\Repositories\UserPreferencesRepository;

class UserPreferencesServiceTest extends TestCase
{
    /**
     * @var \Mockery\LegacyMockInterface&\App\Modules\Articles\Repositories\UserPreferencesRepository
     */
    protected $preferencesRepo;

    /**
     * @var \App\Modules\Articles\Services\UserPreferencesService
     */
    protected $preferencesService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->preferencesRepo = Mockery::mock(UserPreferencesRepository::class);
        $this->preferencesService = new UserPreferencesService($this->preferencesRepo);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /** @test */
    public function it_saves_valid_preferences()
    {
        $userId = 1;
        $preferences = [
            'topics' => ['Technology', 'Health'],
            'sources' => ['Source 1', 'Source 2'],
            'authors' => ['Author A', 'Author B'],
        ];

        $this->preferencesRepo
            ->shouldReceive('savePreferences')
            ->with($userId, $preferences)
            ->once();

        $this->preferencesService->setPreferences($userId, $preferences);

        $this->assertTrue(true); // No exception means success
    }

    /** @test */
    public function it_throws_error_for_invalid_preferences()
    {
        $userId = 1;
        $preferences = [
            'topics' => ['Invalid Topic'],
        ];

        $this->preferencesRepo
            ->shouldReceive('validatePreferences')
            ->with($preferences)
            ->andThrow(new \InvalidArgumentException('Invalid topic provided.'));

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid topic provided.');

        $this->preferencesService->setPreferences($userId, $preferences);
    }

    /** @test */
    public function it_handles_empty_preferences_gracefully()
    {
        $userId = 1;
        $preferences = [];

        $this->preferencesRepo
            ->shouldReceive('savePreferences')
            ->with($userId, $preferences)
            ->once();

        $this->preferencesService->setPreferences($userId, $preferences);

        $this->assertTrue(true); // No exception means success
    }

    /** @test */
    public function it_retrieves_user_preferences()
    {
        $userId = 1;
        $mockPreferences = [
            'topics' => ['Technology'],
            'sources' => ['Source 1'],
            'authors' => ['Author A'],
        ];

        $this->preferencesRepo
            ->shouldReceive('getPreferences')
            ->with($userId)
            ->once()
            ->andReturn($mockPreferences);

        $result = $this->preferencesService->getPreferences($userId);

        $this->assertEquals($mockPreferences, $result);
    }

    /** @test */
    public function it_returns_empty_preferences_if_none_exist()
    {
        $userId = 1;

        $this->preferencesRepo
            ->shouldReceive('getPreferences')
            ->with($userId)
            ->once()
            ->andReturn([]);

        $result = $this->preferencesService->getPreferences($userId);

        $this->assertEquals([], $result);
    }

    /** @test */
    public function it_throws_exception_when_retrieving_preferences_fails()
    {
        $userId = 1;

        $this->preferencesRepo
            ->shouldReceive('getPreferences')
            ->with($userId)
            ->once()
            ->andThrow(new \RuntimeException('Failed to fetch preferences.'));

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Failed to fetch preferences.');

        $this->preferencesService->getPreferences($userId);
    }

    /** @test */
    public function it_throws_exception_when_saving_preferences_fails()
    {
        $userId = 1;
        $preferences = [
            'topics' => ['Technology'],
        ];

        $this->preferencesRepo
            ->shouldReceive('savePreferences')
            ->with($userId, $preferences)
            ->once()
            ->andThrow(new \RuntimeException('Failed to save preferences.'));

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Failed to save preferences.');

        $this->preferencesService->setPreferences($userId, $preferences);
    }
}