<?php

namespace Tests\Unit;

use Tests\TestCase;
use Mockery;
use App\Modules\Articles\Services\TopicService;
use App\Modules\Articles\Repositories\TopicRepository;

class TopicServiceTest extends TestCase
{
    /**
     * @var \Mockery\LegacyMockInterface&\App\Modules\Articles\Repositories\TopicRepository
     */
    protected $topicRepo;

    /**
     * @var \App\Modules\Articles\Services\TopicService
     */
    protected $topicService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->topicRepo = Mockery::mock(TopicRepository::class);
        $this->topicService = new TopicService($this->topicRepo);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /** @test */
    public function it_fetches_all_topics()
    {
        $mockTopics = [
            ['id' => 1, 'name' => 'Technology'],
            ['id' => 2, 'name' => 'Health'],
        ];

        $this->topicRepo
            ->shouldReceive('getAllTopics')
            ->once()
            ->andReturn($mockTopics);

        $result = $this->topicService->getTopics();

        $this->assertEquals($mockTopics, $result);
    }

    /** @test */
    public function it_returns_empty_array_when_no_topics_exist()
    {
        $this->topicRepo
            ->shouldReceive('getAllTopics')
            ->once()
            ->andReturn([]);

        $result = $this->topicService->getTopics();

        $this->assertEquals([], $result);
    }

    /** @test */
    public function it_handles_runtime_exceptions_when_fetching_topics()
    {
        $this->topicRepo
            ->shouldReceive('getAllTopics')
            ->once()
            ->andThrow(new \RuntimeException('Runtime error'));

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Runtime error');

        $this->topicService->getTopics();
    }

    /** @test */
    public function it_handles_general_exceptions_when_fetching_topics()
    {
        $this->topicRepo
            ->shouldReceive('getAllTopics')
            ->once()
            ->andThrow(new \Exception('Unexpected error'));

        $this->expectException(\Exception::class);
        $this->expectExceptionMessage('Unexpected error');

        $this->topicService->getTopics();
    }
}