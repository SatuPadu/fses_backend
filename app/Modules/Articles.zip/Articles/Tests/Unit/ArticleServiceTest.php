<?php

namespace Tests\Unit;

use Tests\TestCase;
use Mockery;
use App\Modules\Articles\Services\ArticleService;
use App\Modules\Articles\Repositories\ArticleRepository;

class ArticleServiceTest extends TestCase
{
    /**
     * @var \Mockery\LegacyMockInterface&\App\Modules\Articles\Repositories\ArticleRepository
     */
    protected $articleRepo;

    /**
     * @var \App\Modules\Articles\Services\ArticleService
     */
    protected $articleService;

    protected function setUp(): void
    {
        parent::setUp();
        $this->articleRepo = Mockery::mock(ArticleRepository::class);
        $this->articleService = new ArticleService($this->articleRepo);
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /** @test */
    public function it_fetches_article_by_valid_id()
    {
        $articleId = 1;
        $mockArticle = ['id' => $articleId, 'title' => 'Sample Article'];

        $this->articleRepo
            ->shouldReceive('getArticleById')
            ->with($articleId)
            ->once()
            ->andReturn($mockArticle);

        $result = $this->articleService->getArticleById($articleId);

        $this->assertEquals($mockArticle, $result);
    }

    /** @test */
    public function it_throws_exception_when_article_not_found()
    {
        $articleId = 999;

        $this->articleRepo
            ->shouldReceive('getArticleById')
            ->with($articleId)
            ->once()
            ->andThrow(new \RuntimeException('Article not found.'));

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Article not found.');

        $this->articleService->getArticleById($articleId);
    }

    /** @test */
    public function it_fetches_sources_by_topics()
    {
        $topics = ['Technology', 'Health'];
        $mockSources = [
            'Technology' => ['Source 1', 'Source 2'],
            'Health' => ['Source 3'],
        ];

        $this->articleRepo
            ->shouldReceive('getSourcesByTopics')
            ->with($topics)
            ->once()
            ->andReturn($mockSources);

        $result = $this->articleService->getSourcesByTopics($topics);

        $this->assertEquals($mockSources, $result);
    }

    /** @test */
    public function it_handles_empty_sources_by_topics()
    {
        $topics = [];
        $mockSources = [];

        $this->articleRepo
            ->shouldReceive('getSourcesByTopics')
            ->with($topics)
            ->once()
            ->andReturn($mockSources);

        $result = $this->articleService->getSourcesByTopics($topics);

        $this->assertEquals([], $result);
    }

    /** @test */
    public function it_throws_exception_when_fetching_sources_fails()
    {
        $topics = ['InvalidTopic'];

        $this->articleRepo
            ->shouldReceive('getSourcesByTopics')
            ->with($topics)
            ->once()
            ->andThrow(new \RuntimeException('Failed to fetch sources.'));

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Failed to fetch sources.');

        $this->articleService->getSourcesByTopics($topics);
    }

    /** @test */
    public function it_fetches_authors_by_topics_and_sources()
    {
        $topics = ['Technology', 'Health'];
        $sources = ['Source 1', 'Source 2'];
        $mockAuthors = [
            'Technology' => ['Author A'],
            'Health' => ['Author B', 'Author C'],
        ];

        $this->articleRepo
            ->shouldReceive('getAuthorsByTopicsAndSources')
            ->with($topics, $sources)
            ->once()
            ->andReturn($mockAuthors);

        $result = $this->articleService->getAuthorsByTopicsAndSources($topics, $sources);

        $this->assertEquals($mockAuthors, $result);
    }

    /** @test */
    public function it_handles_empty_authors_by_topics_and_sources()
    {
        $topics = [];
        $sources = [];
        $mockAuthors = [];

        $this->articleRepo
            ->shouldReceive('getAuthorsByTopicsAndSources')
            ->with($topics, $sources)
            ->once()
            ->andReturn($mockAuthors);

        $result = $this->articleService->getAuthorsByTopicsAndSources($topics, $sources);

        $this->assertEquals([], $result);
    }

    /** @test */
    public function it_throws_exception_when_fetching_authors_fails()
    {
        $topics = ['Technology'];
        $sources = ['Source 1'];

        $this->articleRepo
            ->shouldReceive('getAuthorsByTopicsAndSources')
            ->with($topics, $sources)
            ->once()
            ->andThrow(new \RuntimeException('Failed to fetch authors.'));

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Failed to fetch authors.');

        $this->articleService->getAuthorsByTopicsAndSources($topics, $sources);
    }
}